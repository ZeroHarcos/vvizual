﻿#nullable disable
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace BuisnessTransactionsApp
{
    // Az adatbázis kontextus osztály, amely tartalmazza az összes DbSet-et, amellyel az entitásokat kezeljük.
    public partial class BuisnessTransactionsDbModel : DbContext
    {
        // Alapértelmezett konstruktor, amely meghívja a `OnCreated` metódust a létrehozás után.
        public BuisnessTransactionsDbModel() : base()
        {
            OnCreated(); // Inicializálás és egyéni beállítások alkalmazása.
        }

        // Konstruktor, amely paraméterként kapott DbContextOptions-t is használ.
        public BuisnessTransactionsDbModel(DbContextOptions<BuisnessTransactionsDbModel> options) : base(options)
        {
            OnCreated(); // Inicializálás és egyéni beállítások alkalmazása.
        }

        // Részleges metódus a konfiguráció testreszabásához.
        partial void CustomizeConfiguration(ref DbContextOptionsBuilder optionsBuilder);

        // DbSet-ek, amelyek az adatbázis táblákat reprezentálják.
        public virtual DbSet<Customer> Customers { get; set; } 
        public virtual DbSet<Product> Products { get; set; }   
        public virtual DbSet<TransactionItem> TransactionItems { get; set; } 
        public virtual DbSet<Transaction> Transactions { get; set; } 

        // A modellek létrehozásakor meghívott metódus, amely tartalmazza az összes entitás konfigurálását.
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Az alapértelmezett beállítások alkalmazása.

            // A különböző entitások konfigurációja
            this.CustomerMapping(modelBuilder);
            this.ProductMapping(modelBuilder);
            this.TransactionItemMapping(modelBuilder);
            this.TransactionMapping(modelBuilder);
            this.RelationshipsMapping(modelBuilder);
            CustomizeMapping(ref modelBuilder); 
        }

        #region Customer Mapping 
        
        private void CustomerMapping(ModelBuilder modelBuilder)
        {
            
        }

        
        partial void CustomizeCustomerMapping(ModelBuilder modelBuilder);
        #endregion

        #region Product Mapping
        
        private void ProductMapping(ModelBuilder modelBuilder)
        {
            
        }

        
        partial void CustomizeProductMapping(ModelBuilder modelBuilder);
        #endregion

        #region TransactionItem Mapping
        
        private void TransactionItemMapping(ModelBuilder modelBuilder)
        {
           
        }

        
        partial void CustomizeTransactionItemMapping(ModelBuilder modelBuilder);
        #endregion

        #region Transaction Mapping
       
        private void TransactionMapping(ModelBuilder modelBuilder)
        {
            
        }

        
        partial void CustomizeTransactionMapping(ModelBuilder modelBuilder);
        #endregion

        
        private void RelationshipsMapping(ModelBuilder modelBuilder)
        {
           
        }

        
        partial void CustomizeMapping(ref ModelBuilder modelBuilder);

        
        partial void OnCreated();
    }
}
