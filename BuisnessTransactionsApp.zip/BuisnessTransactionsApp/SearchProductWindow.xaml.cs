﻿using System;
using System.Linq;
using System.Windows;

namespace BuisnessTransactionsApp
{
    public partial class SearchProductWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context; // Az adatbázis kontextus, amely az adatokat kezeli.

        // Konstruktor, amely beállítja az ablakot és az adatbázis kontextust a kereséshez.
        public SearchProductWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent(); 
            _context = context;
            this.Title = "Search Products"; 
        }

        // A 'Search' gomb kattintásakor végrehajtódó művelet.
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchTermTextBox.Text; // A keresett kifejezés a szövegdobozból.

            try
            {
                // Alapértelmezett lekérdezés, amely az összes terméket tartalmazza.
                IQueryable<Product> query = _context.Products;

                // Ha van keresett kifejezés, szűrjük a termékeket a név alapján.
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    query = query.Where(p => p.Name.Contains(searchTerm)); // A keresett kifejezés tartalmú nevekre szűrés.
                }

                // A keresett termékek listájának lekérése az adatbázisból.
                var results = query.ToList();

                // Az eredmények megjelenítése a DataGrid-en.
                ResultsDataGrid.ItemsSource = results;

                // Ha nincs találat és a keresett kifejezés nem üres, üzenet jelenik meg.
                if (!results.Any() && !string.IsNullOrWhiteSpace(searchTerm))
                {
                    MessageBox.Show("No products found matching the criteria.", "Search Results", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // Ha hiba történik a keresés során, hibaüzenet jelenik meg.
                MessageBox.Show($"Error during search: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // A 'Close' gomb kattintásakor bezárjuk az ablakot.
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
