﻿using System;
using System.Linq;
using System.Windows;

namespace BuisnessTransactionsApp
{
    public partial class SearchCustomerWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context; // Az adatbázis kontextus, amely az adatokat kezeli.

        // Konstruktor, amely beállítja az ablakot és az adatbázis kontextust a kereséshez.
        public SearchCustomerWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent(); 
            _context = context;
            this.Title = "Search Customers"; 
        }

        // A 'Close' gomb kattintásakor bezárjuk az ablakot.
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // Ablak bezárása.
        }

        // A 'Search' gomb kattintásakor végrehajtódó művelet.
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchTermTextBox.Text; // A keresett kifejezés a szövegdobozból.

            try
            {
                // Alapértelmezett lekérdezés, amely az összes vásárlót tartalmazza.
                IQueryable<Customer> query = _context.Customers;

                // Ha van keresett kifejezés, szűrjük a vásárlókat a név alapján.
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    query = query.Where(c => c.Name.Contains(searchTerm)); // A keresett kifejezés tartalmú nevekre szűrés.
                }

                // A keresett vásárlók listájának lekérése az adatbázisból.
                var results = query.ToList();

                // Az eredmények megjelenítése a DataGrid-en.
                ResultsDataGrid.ItemsSource = results;

                // Ha nincs találat, üzenet jelenik meg.
                if (!results.Any())
                {
                    MessageBox.Show("No customers found matching the criteria.", "Search Results", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // Ha hiba történik a keresés során, hibaüzenet jelenik meg.
                MessageBox.Show($"Error during search: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        
        private void SearchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            
        }
    }
}
