﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace BuisnessTransactionsApp
{
    public partial class SearchTransactionWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context; // Az adatbázis kontextus, amely az adatokat kezeli.

        // Konstruktor, amely beállítja az ablakot és az adatbázis kontextust.
        public SearchTransactionWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent(); // Az ablak inicializálása.
            _context = context;
            this.Title = "Search Transactions"; // Ablak címének beállítása.
        }

        // A 'Search' gomb kattintásakor végrehajtódó művelet.
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchTermTextBox.Text.Trim(); // A keresett kifejezés a szövegdobozból.

            // Ha nincs megadva keresési kifejezés, töröljük az eredményeket és kilépünk.
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                SearchResultsGrid.ItemsSource = null; // Eredmények törlése.
                return;
            }

            try
            {
                // Keresett kifejezés kisbetűs változata.
                string searchTermLower = searchTerm.ToLower();

                // Lekérdezés, amely figyelembe veszi a státuszt és a vevő nevét is.
                var results = _context.Transactions
                                      .Include(t => t.Customer) // A kapcsolódó vevő adatait is betöltjük.
                                      .Where(t =>
                                          (t.Status != null && t.Status.ToLower().Contains(searchTermLower)) || // Státusz szűrés.
                                          (t.Customer != null && t.Customer.Name != null && t.Customer.Name.ToLower().Contains(searchTermLower)) // Vevő név szűrés.
                                       )
                                      .OrderByDescending(t => t.Date) // Legújabb tranzakciók kerülnek előre.
                                      .ToList(); // Az eredmények listává alakítása.

                // Az eredmények megjelenítése a DataGrid-en.
                SearchResultsGrid.ItemsSource = results;

                // Ha nincs találat, üzenet jelenik meg.
                if (!results.Any())
                {
                    MessageBox.Show($"No transactions found matching '{searchTerm}'.", "Search Results", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // Ha hiba történik a keresés során, hibaüzenet jelenik meg.
                MessageBox.Show($"Error during search: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // A 'Edit' gomb kattintásakor végrehajtódó művelet.
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // A kiválasztott tranzakció lekérése a keresési eredményekből.
            Transaction selectedTransaction = SearchResultsGrid.SelectedItem as Transaction;
            if (selectedTransaction == null)
            {
                MessageBox.Show("Please select a transaction from the search results to edit.", "Selection Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return; 
            }

            try
            {
                // Megnyitjuk az EditTransactionWindow ablakot a kiválasztott tranzakcióval.
                EditTransactionWindow editWin = new EditTransactionWindow(_context, selectedTransaction.TransactionID);
                editWin.Owner = this; // Beállítjuk, hogy az új ablak az aktuális ablak tulajdonosa legyen.

                // A szerkesztett tranzakció ablak megnyitása modális ablakként.
                bool? result = editWin.ShowDialog();

                // Ha a szerkesztés sikeres, újraindítjuk a keresést, hogy frissítsük az eredményeket.
                if (result == true)
                {
                    SearchButton_Click(sender, e); 
                }
            }
            catch (Exception ex)
            {
                // Ha hiba történik a szerkesztés megnyitása során, hibaüzenet jelenik meg.
                MessageBox.Show($"Error opening edit transaction window: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

       
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // Ablak bezár
        }
    }
}
