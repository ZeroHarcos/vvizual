﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace BuisnessTransactionsApp
{
    public partial class MainWindow : Window
    {
        // Adatbázis kontextus és szolgáltatásgyűjtő (DI container referencia)
        private readonly BuisnessTransactionsDbModel _context;
        private readonly IServiceProvider _serviceProvider;

        // Konstruktor - a főablak példányosítása dependency injection segítségével
        public MainWindow(BuisnessTransactionsDbModel context, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _context = context;
            _serviceProvider = serviceProvider;
        }

        // Ablak betöltésekor automatikusan betölti az adatokat
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCustomerData();
            LoadProductData();
            LoadTransactionData();
        }

        // Tranzakciós adatok betöltése és kiírása DataGrid-be
        private void LoadTransactionData()
        {
            try
            {
                var transactions = _context.Transactions
                                           .Include(t => t.Customer) // Ügyfélkapcsolat betöltése is (join)
                                           .ToList();

                TransactionDataGrid.ItemsSource = transactions;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Hiba a tranzakció adatok betöltése közben: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Adatbázis Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Ügyféladatok betöltése 
        private void LoadCustomerData(string searchTerm = null)
        {
            try
            {
                IQueryable<Customer> query = _context.Customers;
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    //név alapú szűrés
                    query = query.Where(c => c.Name.Contains(searchTerm));
                }
                var customers = query.ToList();
                CustomerDataGrid.ItemsSource = customers;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Hiba a vevő adatok betöltése közben: {ex.Message}...", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Új ügyfél hozzáadása ablak megnyitásával
        private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            CustomerWindow addCustomerWin = new CustomerWindow(_context);
            bool? result = addCustomerWin.ShowDialog();
            if (result == true) { LoadCustomerData(); }
        }

        // Kijelölt ügyfél szerkesztése
        private void EditCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            Customer selectedCustomer = CustomerDataGrid.SelectedItem as Customer;
            if (selectedCustomer == null) { return; }
            CustomerWindow editWin = new CustomerWindow(_context, selectedCustomer);
            bool? result = editWin.ShowDialog();
            if (result == true) { LoadCustomerData(); }
        }

        // Ügyfél kereső ablak megnyitása
        private void SearchCustomersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var searchWindow = _serviceProvider.GetRequiredService<SearchCustomerWindow>();
                searchWindow.Owner = this;
                searchWindow.Show();
            }
            catch (Exception ex) {  }
        }

        // Termékadatok betöltése
        private void LoadProductData()
        {
            try
            {
                var products = _context.Products.ToList();
                ProductDataGrid.ItemsSource = products;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Hiba a termék adatok betöltése közben: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Adatbázis Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Új termék hozzáadása
        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            ProductWindow addProductWin = new ProductWindow(_context);
            bool? result = addProductWin.ShowDialog();
            if (result == true)
            {
                LoadProductData();
            }
        }

        // Termék szerkesztése
        private void EditProductButton_Click(object sender, RoutedEventArgs e)
        {
            Product selectedProduct = ProductDataGrid.SelectedItem as Product;
            if (selectedProduct == null)
            {
                MessageBox.Show("Please select a product to edit.", "Selection Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProductWindow editProductWin = new ProductWindow(_context, selectedProduct);
            bool? result = editProductWin.ShowDialog();
            if (result == true)
            {
                LoadProductData();
            }
        }

        // Új tranzakció hozzáadása
        private void AddTransactionButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AddTransactionWindow addTransactionWindow = new AddTransactionWindow(_context);
                bool? result = addTransactionWindow.ShowDialog();
                if (result == true)
                {
                    LoadTransactionData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening add transaction window: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Termék kereső ablak megnyitása
        private void SearchProductsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var searchWindow = _serviceProvider.GetRequiredService<SearchProductWindow>();
                searchWindow.Owner = this;
                searchWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening product search window: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Tranzakció szerkesztés – csak akkor, ha van kiválasztva
        private void EditTransactionButton_Click(object sender, RoutedEventArgs e)
        {
            Transaction selectedTransaction = TransactionDataGrid.SelectedItem as Transaction;
            if (selectedTransaction == null)
            {
                MessageBox.Show("Please select a transaction to edit.", "Selection Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                EditTransactionWindow editWin = new EditTransactionWindow(_context, selectedTransaction.TransactionID);
                editWin.Owner = this;
                bool? result = editWin.ShowDialog();

                if (result == true)
                {
                    LoadTransactionData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening edit transaction window: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void SearchTransactionsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                var searchWindow = _serviceProvider.GetRequiredService<SearchTransactionWindow>();
                searchWindow.Owner = this;
                
                searchWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening search transaction window: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
