﻿using System;
using System.Linq;
using System.Windows;

namespace BuisnessTransactionsApp
{
    public partial class CustomerWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context;
        private Customer _editableCustomer = null; 

        // Új vevő létrehozásához használt konstruktor
        public CustomerWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent();
            _context = context;
            this.Title = "Add New Customer";
        }

        // Vevő szerkesztéséhez használt konstruktor
        public CustomerWindow(BuisnessTransactionsDbModel context, Customer customerToEdit)
        {
            InitializeComponent();
            _context = context;

            if (customerToEdit == null) { } 
            _editableCustomer = customerToEdit;

            // Mezők feltöltése az adatokkal
            NameTextBox.Text = _editableCustomer.Name;
            EmailTextBox.Text = _editableCustomer.Email;
            PhoneTextBox.Text = _editableCustomer.Phone;

            this.Title = "Edit Customer";
        }

        // Mentés gomb kattintásra
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Egyszerű validáció – csak név kötelező
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Please enter the customer's name.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (_editableCustomer == null) // Új vevő mentése
                {
                    var newCustomer = new Customer
                    {
                        Name = NameTextBox.Text,
                        Email = EmailTextBox.Text,
                        Phone = PhoneTextBox.Text
                    };

                    _context.Customers.Add(newCustomer);
                    MessageBox.Show("Customer added successfully!", "Save Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else // Meglévő vevő frissítése
                {
                    var customerToUpdate = _context.Customers.Find(_editableCustomer.CustomerID);
                    if (customerToUpdate != null)
                    {
                        customerToUpdate.Name = NameTextBox.Text;
                        customerToUpdate.Email = EmailTextBox.Text;
                        customerToUpdate.Phone = PhoneTextBox.Text;

                        MessageBox.Show("Customer updated successfully!", "Update Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Customer not found in database.", "Update Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                }

                _context.SaveChanges(); // Adatbázis mentés
                this.DialogResult = true;
                this.Close(); // Ablak bezárása sikeres mentés után
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving changes: {ex.Message}...", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
