﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;

namespace BuisnessTransactionsApp
{
    public partial class ProductWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context; // Az adatbázis kontextus, amely az adatokat kezeli.

        private Product _editableProduct = null; // A termék, amit szerkeszteni szeretnénk.

        // Konstruktor, amely beállítja a kontextust és inicializálja az ablakot új termék hozzáadásához.
        public ProductWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent();
            _context = context;
            this.Title = "Add New Product"; // Ablak címének beállítása.
        }

        // Konstruktor, amely beállítja a kontextust és a terméket, ha szerkeszteni szeretnénk egy meglévőt.
        public ProductWindow(BuisnessTransactionsDbModel context, Product productToEdit)
        {
            InitializeComponent();
            _context = context;

            if (productToEdit == null)
            {
                // Ha a termék null, hibaüzenet jelenik meg.
                MessageBox.Show("Error: No product provided for editing.", "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error);
                this.DialogResult = false; // Leáll az ablak.
                this.Close();
                return;
            }

            _editableProduct = productToEdit; // A szerkesztéshez megadott termék beállítása.

            // A termék adatai betöltése a szerkesztéshez.
            ProductNameTextBox.Text = _editableProduct.Name;
            ProductPriceTextBox.Text = _editableProduct.Price.ToString(CultureInfo.InvariantCulture); // Az ár formázása.

            this.Title = "Edit Product"; // Ablak címének módosítása szerkesztés esetén.
        }

        // Mentés gomb kattintásakor végrehajtódó művelet.
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string name = ProductNameTextBox.Text; // A termék neve a szövegdobozból.
            string priceText = ProductPriceTextBox.Text; // A termék ára a szövegdobozból.

            // Ellenőrizzük, hogy a termék neve ki van-e töltve.
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Product Name field cannot be empty.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Ellenőrizzük, hogy az ár érvényes szám-e és nem negatív.
            if (!decimal.TryParse(priceText, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal price) || price < 0)
            {
                MessageBox.Show("Invalid Price. Please enter a non-negative number (e.g., 123.45).", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Ha nincs szerkesztett termék, akkor új terméket adunk hozzá.
                if (_editableProduct == null)
                {
                    var newProduct = new Product
                    {
                        Name = name,
                        Price = price
                    };
                    _context.Products.Add(newProduct); // Új termék hozzáadása az adatbázishoz.
                    MessageBox.Show("Product added successfully!", "Save Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // Ha létezik szerkesztett termék, frissítjük annak adatait.
                    var productToUpdate = _context.Products.Find(_editableProduct.ProductID);

                    if (productToUpdate != null)
                    {
                        productToUpdate.Name = name; // A termék nevét frissítjük.
                        productToUpdate.Price = price; // A termék árát frissítjük.
                        MessageBox.Show("Product updated successfully!", "Update Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        // Ha nem találjuk a terméket, hibaüzenet jelenik meg.
                        MessageBox.Show($"Error: Product with ID {_editableProduct.ProductID} not found.", "Update Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                // Módosítások mentése az adatbázisba.
                _context.SaveChanges();

                this.DialogResult = true; // Sikeres mentés után a visszajelzés.
                this.Close(); // Ablak bezárása.
            }
            catch (Exception ex)
            {
                // Ha hiba történik a mentés során, hibaüzenet jelenik meg.
                MessageBox.Show($"Error saving product: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
