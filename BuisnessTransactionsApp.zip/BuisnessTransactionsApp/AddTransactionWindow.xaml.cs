﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BuisnessTransactionsApp
{
    // Segédmodell a kosárban lévő termékekhez (nem mentjük adatbázisba!)
    public class CartItemViewModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }

        // Számított érték
        public decimal TotalPrice { get { return Quantity * UnitPrice; } }
    }

    public partial class AddTransactionWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context;

        // Kosár tartalma 
        private List<CartItemViewModel> _cartItems = new List<CartItemViewModel>();

        public AddTransactionWindow(BuisnessTransactionsDbModel context)
        {
            InitializeComponent();
            _context = context;
            this.Title = "Add New Transaction";
            LoadCustomersIntoComboBox();
            LoadAvailableProducts();
            SetDefaultValues();
        }

        // Vevők betöltése a lenyíló listába
        private void LoadCustomersIntoComboBox()
        {
            try
            {
                CustomerComboBox.ItemsSource = _context.Customers.OrderBy(c => c.Name).ToList();
                CustomerComboBox.DisplayMemberPath = "Name";
                CustomerComboBox.SelectedValuePath = "CustomerID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading customers: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Termékek betöltése a választható listába
        private void LoadAvailableProducts()
        {
            try
            {
                AvailableProductsGrid.ItemsSource = _context.Products.OrderBy(p => p.Name).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading products: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Alapértelmezett beállítások: mai dátum, státusz kiválasztva, összeg nullázva
        private void SetDefaultValues()
        {
            TransactionDatePicker.SelectedDate = DateTime.Today;
            StatusComboBox.SelectedIndex = 0;
            UpdateTotalAmount();
        }

        // Termék hozzáadása a kosárhoz
        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            Product selectedProduct = AvailableProductsGrid.SelectedItem as Product;
            if (selectedProduct == null)
            {
                MessageBox.Show("Please select a product...", "Selection Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid positive quantity.", "Invalid Quantity", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var cartItem = new CartItemViewModel
            {
                ProductID = selectedProduct.ProductID,
                ProductName = selectedProduct.Name,
                Quantity = quantity,
                UnitPrice = selectedProduct.Price
            };

            _cartItems.Add(cartItem);
            RefreshCartGrid();
            UpdateTotalAmount();
            QuantityTextBox.Text = "1"; 
        }

        // Termék eltávolítása a kosárból
        private void RemoveProductButton_Click(object sender, RoutedEventArgs e)
        {
            CartItemViewModel selectedCartItem = TransactionItemsGrid.SelectedItem as CartItemViewModel;
            if (selectedCartItem == null)
            {
                MessageBox.Show("Please select an item from the cart...", "Selection Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _cartItems.Remove(selectedCartItem);
            RefreshCartGrid();
            UpdateTotalAmount();
        }

        // Kosár megjelenítés frissítése
        private void RefreshCartGrid()
        {
            TransactionItemsGrid.ItemsSource = null;
            TransactionItemsGrid.ItemsSource = _cartItems;
        }

        // Teljes összeg kiszámítása a kosár alapján
        private void UpdateTotalAmount()
        {
            decimal totalAmount = 0;
            foreach (var item in _cartItems)
            {
                totalAmount += item.TotalPrice;
            }
            AmountTextBox.Text = totalAmount.ToString("C", CultureInfo.CurrentCulture);
        }

        
        private void CustomerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        // Tranzakció mentése
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Validációk
            if (CustomerComboBox.SelectedValue == null)
            {
                MessageBox.Show("Please select a customer.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!_cartItems.Any())
            {
                MessageBox.Show("Cannot save an empty transaction. Please add products to the cart.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (StatusComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a status.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Új tranzakció létrehozása
            int customerId = (int)CustomerComboBox.SelectedValue;
            DateTime transactionDate = TransactionDatePicker.SelectedDate ?? DateTime.Now;
            string status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Pending";
            decimal totalAmount = _cartItems.Sum(item => item.TotalPrice);

            var newTransaction = new Transaction
            {
                CustomerID = customerId,
                Date = transactionDate,
                Amount = totalAmount,
                Status = status,
                TransactionItems = new List<TransactionItem>()
            };

            // Kosár tartalmának hozzáadása a tranzakcióhoz
            foreach (var cartItem in _cartItems)
            {
                var newItem = new TransactionItem
                {
                    ProductID = cartItem.ProductID,
                    Quantity = cartItem.Quantity
                };
                newTransaction.TransactionItems.Add(newItem);
            }

            try
            {
                _context.Transactions.Add(newTransaction);
                _context.SaveChanges();

                MessageBox.Show("Transaction saved successfully!", "Save Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving transaction: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}",
                                "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Bezárás gomb
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
