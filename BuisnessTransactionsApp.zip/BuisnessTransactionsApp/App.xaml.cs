﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Windows;

namespace BuisnessTransactionsApp
{
    
    public partial class App : Application
    {
        
        public static IHost? AppHost { get; private set; }

        public App()
        {
            // Az alkalmazás host-jának konfigurálása és építése
            AppHost = Host.CreateDefaultBuilder()
                .ConfigureAppConfiguration((hostContext, config) =>
                {
                    // A konfiguráció betöltése az aktuális könyvtárból
                    config.SetBasePath(Directory.GetCurrentDirectory());
                    config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                })
                .ConfigureServices((hostContext, services) =>
                {
                    // Adatbázis-kapcsolati string beolvasása a konfigurációból
                    string connectionString = hostContext.Configuration.GetConnectionString("BuisnessTransactionsDbModelConnectionString");

                    // DbContext regisztrálása SQL Serverrel
                    services.AddDbContext<BuisnessTransactionsDbModel>(options =>
                    {
                        options.UseSqlServer(connectionString);
                    });

                    // Főablak singletonként, mivel egyszer indul el
                    services.AddSingleton<MainWindow>();

                    // Egyéb ablakok példányosíthatók több alkalommal (transient)
                    services.AddTransient<CustomerWindow>();
                    services.AddTransient<SearchCustomerWindow>();
                    services.AddTransient<ProductWindow>();
                    services.AddTransient<SearchProductWindow>();
                    services.AddTransient<AddTransactionWindow>();
                    services.AddTransient<EditTransactionWindow>();
                    services.AddTransient<SearchTransactionWindow>();
                })
                .Build(); // A host végleges felépítése
        }

        // Az alkalmazás indításakor fut le
        protected override async void OnStartup(StartupEventArgs e)
        {
            // Host indítása (szolgáltatások elérhetővé tétele)
            await AppHost!.StartAsync();

            // Főablak példányosítása a szolgáltatásokból, majd megjelenítése
            var startupWindow = AppHost.Services.GetRequiredService<MainWindow>();
            startupWindow.Show();

            base.OnStartup(e);
        }

        // Alkalmazás bezárásakor fut le
        protected override async void OnExit(ExitEventArgs e)
        {
            // Host leállítása és erőforrások felszabadítása
            await AppHost!.StopAsync();
            AppHost.Dispose();

            base.OnExit(e);
        }
    }
}
