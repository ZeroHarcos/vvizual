﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace BuisnessTransactionsApp
{
    public partial class EditTransactionWindow : Window
    {
        private readonly BuisnessTransactionsDbModel _context; 
        private Transaction _editableTransaction; 
        private int _transactionIdToEdit; 

        
        public EditTransactionWindow(BuisnessTransactionsDbModel context, int transactionIdToEdit)
        {
            InitializeComponent();
            _context = context;
            _transactionIdToEdit = transactionIdToEdit;
            this.Title = $"Edit Transaction (ID: {transactionIdToEdit})"; 
            this.Loaded += EditTransactionWindow_Loaded; 
        }

        // Betölti az adatokat a tranzakció szerkesztéséhez
        private void EditTransactionWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                
                _editableTransaction = _context.Transactions
                                               .Include(t => t.Customer) 
                                               .FirstOrDefault(t => t.TransactionID == _transactionIdToEdit); 

                
                if (_editableTransaction == null)
                {
                    MessageBox.Show($"Error: Transaction with ID {_transactionIdToEdit} not found.", "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    this.DialogResult = false; // Leállítjuk az ablakot, nem lehet menteni.
                    this.Close();
                    return;
                }

                // A tranzakció adatai beállítása a UI-ban.
                TransactionIdTextBlock.Text = _editableTransaction.TransactionID.ToString();
                CustomerNameTextBlock.Text = _editableTransaction.Customer?.Name ?? "N/A"; 
                AmountTextBlock.Text = _editableTransaction.Amount.ToString("C"); 
                TransactionDatePicker.SelectedDate = _editableTransaction.Date; 

                
                foreach (ComboBoxItem item in StatusComboBox.Items)
                {
                    if (item.Content.ToString() == _editableTransaction.Status)
                    {
                        StatusComboBox.SelectedItem = item;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show($"Error loading transaction data: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
                this.DialogResult = false; 
                this.Close();
            }
        }

        // Mentés gomb művelet.
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_editableTransaction == null) return; 

            DateTime? newDate = TransactionDatePicker.SelectedDate; 
            string newStatus = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString(); 

            //dátum nem lett kiválasztva
            if (newDate == null)
            {
                MessageBox.Show("Please select a valid date.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            //státusz nem lett kiválasztva
            if (string.IsNullOrEmpty(newStatus))
            {
                MessageBox.Show("Please select a status.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                //tranzakció frissítése
                _editableTransaction.Date = newDate.Value;
                _editableTransaction.Status = newStatus;

                //adatbázis frissítése
                _context.SaveChanges();

                
                MessageBox.Show("Transaction status updated successfully!", "Update Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                //hiba mentéskor
                MessageBox.Show($"Error updating transaction: {ex.Message}\n\nInnerException: {ex.InnerException?.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
